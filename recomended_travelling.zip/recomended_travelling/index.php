<!DOCTYPE html>
<html>
<head>
	<title>Nabila Travelling</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>

<body>

<nav class="blue">
	<div class="container">
	<a href="index.php?p=home" class="brand-logo">Recomended Travelling</a>
	<a href="#!" class="sidenav-trigger" data-target="mobile-demo"><i class="material-icons">menu</i></a>
		<ul id="nav-mobile" class="right hide-on-med-and-down">
			<li><a href="index.php?p=home">Home</a></li>
			<li><a href="index.php?p=destinasi">Destinasi</a></li>
			<li><a href="index.php?p=gallery">Gallery</a></li>
			<li><a href="index.php?p=Contact">Contact</a></li>
		</ul>
		<ul class="sidenav" id="mobile-demo">
			<li><a href="index.php?p=home">Home</a></li>
			<li><a href="index.php?p=destinasi">Destinasi</a></li>
			<li><a href="index.php?p=gallery">Gallery</a></li>
			<li><a href="index.php?p=Contact">Contact</a></li>
		</ul>
	</div>
</nav>

<?php 
	if (@$_GET['p']=="") {
		include_once 'page/home.php';
	}
	elseif (@$_GET['p']=="home") {
		include_once 'page/home.php';
	}
	elseif (@$_GET['p']=="destinasi") {
		include_once 'page/destinasi.php';
	}
	elseif (@$_GET['p']=="gallery") {
		include_once 'page/gallery.php';
	}
	elseif (@$_GET['p']=="Contact") {
		include_once 'page/Contact.php';
	}
 ?>
<div class="footer-copyright white-text cyan accent-4">
  <footer class="page-footer cyan accent-4 darken-4 white-text">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="light">CONTACT</h5>
                <ul>
                  <p><a href="#!"><i class="material-icons white-text">email</i></a> nabilayosyka@gmail.com</p>
                   <p><a href="#!"><i class="material-icons white-text">store_mall_directory</i></a> 111 Main Street, Payakumbuh City, 20921</p>
                  <p><a href="#!"><i class="material-icons white-text">local_phone</i></a>  09121422376</p>
                </ul>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="light">Follow my akun social media</h5>
                <p>follow us on social media for special</p>
                <ul class="white">
                  <a href="#!"><i class="fab fa-facebook fa-2x blue-text text-darken-4 lbr"></i></a>
                  <a href="#!"><i class="fab fa-google-plus fa-2x red-text lbr"></i></a>
                  <a href="#!"><i class="fab fa-steam fa-2x light-blue-text text-darken-4 lbr"></i></a>
                  <a href="#!"><i class="fab fa-youtube fa-2x red-text lbr"></i></a>
                  <a href="#!"><i class="fab fa-telegram fa-2x blue-text lbr"></i></a>
                </ul>
              </div>
            </div>
          </div>
<div class="footer-copyright">
	<div class="container">
		© 2018 Copyright <a class="grey-text text-lighten-4" href="#!"> || Nabila Yosyka</a>
	</div>
</div>
    </footer>

<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript">
	const sidenav = document.querySelectorAll('.sidenav');
	M.Sidenav.init(sidenav);

	const parallax = document.querySelectorAll('.parallax');
	M.Parallax.init(parallax);

	const materialboxed = document.querySelectorAll('.materialboxed');
	M.Materialboxed.init(materialboxed);
</script>
</body>
</html>