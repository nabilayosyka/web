<?php 
include "admin/koneksi.php";
session_start();
session_destroy();
	echo "<script>alert('Anda Berhasil logout')</script>";
	echo "<script>location='index.php?p=home';</script>";

 ?>