<div class="row container">
  <h3 class="center red-text">Destinasi Wisata</h3>
  <div class="progress">
    <div class="determinate" style="width: 100%;"></div>
  </div>
<?php 
  include './admin/koneksi.php';
  $sql=mysqli_query($link,"SELECT * FROM tb_destinasi ORDER BY id ASC");
  while ($r=mysqli_fetch_array($sql)) { ?>

    <div class="col s12 m4">
      <div class="card">
        <div class="card-image">
          <img src="./admin/img/<?php echo $r['gbr']; ?>">
          <span class="card-title"><?php echo $r['destinasi']; ?></span>
        </div>
        <div class="card-content">
          <p><?php echo $r['deskripsi']; ?></p>
        </div>
        <div class="card-action">
          <a href="#">Read More</a>
        </div>
      </div>
    </div>


<?php  }
 ?>

</div>

