<div class="container">
	<h3 class="center blue-text">Contact</h3>
	<div class="progress"><div class="determinate" style="width: 100%;"></div></div>
	<div class="card-panel">
		<table>
			<tr class="red-text">
				<td><h4>E-mail</h4></td>
				<td><h4>:</h4></td>
				<td><h4>nabilayosyka@gmail.com</h4></td>
			</tr>

			<tr class="green-text">
				<td><h4>Whatsapp</h4></td>
				<td><h4>:</h4></td>
				<td><h4>+62 812 6894 7514</h4></td>
			</tr>

			<tr class="purple-text">
				<td><h4>Instagram</h4></td>
				<td><h4>:</h4></td>
				<td><h4>@_nabilayosyka</h4></td>
			</tr>

		</table>
	</div>
</div>