<div class="container">
	<h3 class="center blue-text">Gallery</h3>
	<div class="progress">
		<div class="determinate" style="width: 100%;"></div>
	</div>
	<div class="row">
		<div class="col s12 m4">
			<div class="card-panel">
				<img class="responsive-img" src="image/1.jpg">
			</div>
		</div>

		<div class="col s12 m4">
 			<div class="card-panel">
 				<img class="responsive-img" src="image/2.jpg">
 			</div>
 		</div>

		<div class="col s12 m4">
 			<div class="card-panel">
 				<img class="responsive-img" src="image/3.jpg">
 			</div>
		</div>

		<div class="col s12 m4">
			<div class="card-panel">
				<img class="responsive-img" src="image/4.jpg">
			</div>
		</div>

		<div class="col s12 m4">
 			<div class="card-panel">
 				<img class="responsive-img" src="image/5.jpg">
 			</div>
 		</div>

		<div class="col s12 m4">
 			<div class="card-panel">
 				<img class="responsive-img" src="image/6.jpg">
 			</div>
		</div>

	</div>
</div>