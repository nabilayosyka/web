<div class="parallax-container">
      <div class="parallax"><img src="./image/12.jpg"></div>

<div class="caption center">
  <div class="section"></div>
  <img src="image/yosy.jpg" class="circle responsive-img z-depth-5 hide-on-small-only" style="width: 20%;"><br>
  <img src="image/yosy.jpg" class="circle responsive-img z-depth-5 hide-on-med-and-up" style="width: 80%;"><br>     

  <a href="index.php?p=destinasi" class="btn-large blue waves-light lighteen-1 z-depth-5">Recomended Travelling</a>

</div>

</div>

<div class="section white">
  <div class="row container">

  <h3 class="center red-text">Destinasi Populer</h3>
  <div class="progress">
    <div class="determinate" style="width: 100%;"></div>
  </div>
<?php 
  include './admin/koneksi.php';
  $sql=mysqli_query($link,"SELECT * FROM tb_destinasi ORDER BY id ASC LIMIT 2");
  while ($r=mysqli_fetch_array($sql)) { ?>

    <div class="col s12 m6">
      <div class="card">
        <div class="card-image">
          <img src="./admin/img/<?php echo $r['gbr']; ?>">
          <span class="card-title"><?php echo $r['destinasi']; ?></span>
        </div>
        <div class="card-content">
          <p><?php echo $r['deskripsi']; ?></p>
        </div>
        <div class="card-action">
          <a href="#">Read More</a>
        </div>
      </div>
    </div>


<?php  }
 ?>

  </div>
</div>

<div class="parallax-container">
  <div class="parallax"><img src="image/10.jpg" class="responsive-img"></div>
</div>

