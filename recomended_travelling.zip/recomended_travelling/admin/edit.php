<?php 
	session_start();
	include 'koneksi.php';
	if(!isset($_SESSION['username'])){
		echo "<script>alert('Anda Harus login')</script>";
		echo "<script>location='../login.php';</script>";
	}
	$id=$_GET['id'];
	$sql=mysqli_query($link,"SELECT * FROM tb_destinasi WHERE id='$id'");
	$r=mysqli_fetch_array($sql);
 ?>

<center>
	
<h1>Edit Data</h1>
	<div class="container">
		<form id="form_destinasi" action="" method="post" enctype="multipart/form-data">
			<table border="2">
				<tr>
					<td>Destinasi</td>
					<td>:</td>
					<td><input type="text" name="destinasi" value="<?php echo $r['destinasi']; ?>"></td>
				</tr>
				<tr>
					<td>Alamat</td>
					<td>:</td>
					<td><textarea name="alamat"><?php echo $r['alamat']; ?></textarea></td>
				</tr>
				<tr>
					<td>Tanggal Post</td>
					<td>:</td>
					<td><input type="text" name="tgl_post"  value="<?php echo $r['tgl_post']; ?>"></td>
				</tr>
				<tr>
					<td>Deskripsi</td>
					<td>:</td>
					<td>
						<textarea name="deskripsi"><?php echo $r['deskripsi']; ?></textarea>
					</td>
				</tr>
				<tr>
					<td>Gambar</td>
					<td>:</td>
					<td><input type="file" name="gbr"></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td><img src="img/<?php echo $r['gbr']; ?>" width="100"></td>
				</tr>
			</table>
			<br><input type="submit" name="update" value="Update Data">
		</form>
	</div>

</center>

<?php 
include "koneksi.php";
	if (isset($_POST['update'])){
		$gbr=$_FILES['gbr']['name'];
		$source=$_FILES['gbr']['tmp_name'];
		$folder='./img/';


		if($gbr !=""){
			move_uploaded_file($source, $folder.$gbr);
			$sql=mysqli_query($link,"UPDATE tb_destinasi SET destinasi='".$_POST['destinasi']."',alamat='".$_POST['alamat']."',tgl_post='".$_POST['tgl_post']."',deskripsi='".$_POST['deskripsi']."',gbr='".$gbr."' WHERE id='$id'");
		}
		else{
			$sql=mysqli_query($link,"UPDATE tb_destinasi SET destinasi='".$_POST['destinasi']."',alamat='".$_POST['alamat']."',tgl_post='".$_POST['tgl_post']."',deskripsi='".$_POST['deskripsi']."' WHERE id='$id'");
		}

			if($sql){
				echo "berhasil";
				header("Location:index.php");
			}
			else{
				echo "gagal";
			}
	}
 ?>