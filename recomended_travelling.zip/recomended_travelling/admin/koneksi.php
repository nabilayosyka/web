<?php 
	$link=mysqli_connect("localhost","root","","db_nabila_traveling");
 ?>