<?php 
	include "koneksi.php";
	session_start(); 
	if(!isset($_SESSION['username'])){
		echo "<script>alert('Anda Harus login')</script>";
		echo "<script>location='../login.php';</script>";
	}
?>
<center>
	<h1>Data Destinasi</h1>
	<a href="input.php">Input Data</a> ||
	<a href="../logout.php">Logout</a>
	<table border="5">
		<tr>
			<td>No</td>
			<td>Destinasi</td>
			<td>Alamat</td>
			<td>Tanggal Post</td>
			<td>Deskripsi</td>
			<td>Gambar</td>
			<td>Opsi</td>
<?php 
$no=1;
$sql=mysqli_query($link,"SELECT * FROM tb_destinasi");
while ($r=mysqli_fetch_array($sql)) { ?>
	<tr>
		<td><?php echo $no++; ?></td>
		<td><?php echo $r['destinasi']; ?></td>
		<td><?php echo $r['alamat']; ?></td>
		<td><?php echo $r['tgl_post'] ?></td>
		<td><?php echo $r['deskripsi']; ?></td>
		<td><img src="img/<?php echo $r['gbr']; ?>" width=100></td>
		<td>
			<a href="edit.php?id=<?php echo $r['id']; ?>">Edit</a>
			<a href="hapus.php?id=<?php echo $r['id']; ?>">Hapus</a>
		</td>
	</tr>	
<?php }
 ?>
		</tr>
	</table>
</center>