<?php 
	session_start();
	if(!isset($_SESSION['username'])){
		echo "<script>alert('Anda Harus login')</script>";
		echo "<script>location='../login.php';</script>";
	}
 ?>
<center>	
<h1>Input Data</h1>
	<div class="container">
		<form id="form_destinasi" action="" method="post" enctype="multipart/form-data">
			<table border="2">
				<tr>
					<td>Destinasi</td>
					<td>:</td>
					<td><input type="text" name="destinasi"></td>
				</tr>
				<tr>
					<td>Alamat</td>
					<td>:</td>
					<td><input type="text" name="alamat"></td>
				</tr>
				<tr>
					<td>Tanggal Post</td>
					<td>:</td>
					<td><input type="date" name="tgl_post"></td>
				</tr>
				<tr>
					<td>Deskripsi</td>
					<td>:</td>
					<td>
						<textarea name="deskripsi"></textarea>
					</td>
				</tr>
				<tr>
					<td>Gambar</td>
					<td>:</td>
					<td><input type="file" name="gbr"></td>
				</tr>
			</table>
			<br><input type="submit" name="simpan" value="Simpan Data">
		</form>
	</div>

</center>

<?php 
include "koneksi.php";
	if (isset($_POST['simpan'])){
		$gbr=$_FILES['gbr']['name'];
		$source=$_FILES['gbr']['tmp_name'];
		$folder='./img/';

		move_uploaded_file($source, $folder.$gbr);

		$sql=mysqli_query($link,"INSERT INTO tb_destinasi VALUES(NULL,'".$_POST['destinasi']."','".$_POST['alamat']."',
			'".$_POST['tgl_post']."','".$_POST['deskripsi']."','".$gbr."')");
		if ($sql) {
			echo "berhasil";
		}
		else{
			echo "gagal";
		}
		header("location: index.php"); 

	}
 ?>