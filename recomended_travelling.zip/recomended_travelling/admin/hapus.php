<?php 
	session_start();
	include "koneksi.php";
	if(!isset($_SESSION['username'])){
		echo "<script>alert('Anda Harus login')</script>";
		echo "<script>location='../login.php';</script>";
	}

$delete = mysqli_query($link,"DELETE FROM tb_destinasi WHERE id='".$_GET['id']."'");
if($delete){
	echo "berhasil";
	header("location:index.php");
}
else{
	echo "gagal";
}
?>